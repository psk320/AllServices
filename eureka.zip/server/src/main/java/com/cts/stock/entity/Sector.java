package com.cts.stock.entity;


public class Sector {

}
